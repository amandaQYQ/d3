/**
 * visualMap component entry
 */

import './visualMapContinuous';
import './visualMapPiecewise';
