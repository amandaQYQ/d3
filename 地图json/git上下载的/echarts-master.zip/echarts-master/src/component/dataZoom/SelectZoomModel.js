import DataZoomModel from './DataZoomModel';

export default DataZoomModel.extend({
    type: 'dataZoom.select'
});
